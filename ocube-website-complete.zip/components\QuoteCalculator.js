"use client";
import { useState } from "react";
import styles from "./QuoteCalculator.module.css";

const MATERIALS = [
  { id: "anodised", name: "003 / 005 Anodised Aluminium", desc: "Chemical, UV & high-heat resistant metal plates. For generators, fleet vehicles & plant equipment.", durability: "Highest (15+ Years)" },
  { id: "polyester", name: "3M Polyester 100% Laminated", desc: "Heavy-duty outdoor/indoor film with high scuff resistance. For electronics, appliances & machinery.", durability: "Very High (8-10 Years)" },
  { id: "void", name: "Silver Void Polyester (Tamper-Evident)", desc: "Leaves permanent 'VOID' residue if removed. Perfect for warranty, IT assets & security compliance.", durability: "High Security (5-8 Years)" },
  { id: "polypropylene", name: "Polypropylene Standard Lamination", desc: "Cost-effective, waterproof barcode & QR tracking labels for retail, office furniture & dry stores.", durability: "Medium (3-5 Years)" }
];

const SERVICES = [
  { id: "full", name: "End-to-End Turnkey Audit", desc: "Physical counting + Barcode/RFID Tagging + Register Reconciliation" },
  { id: "tagging", name: "Asset Tagging & Label Production", desc: "Custom printed barcodes/QRs with company logo, affixed on-site" },
  { id: "software", name: "Asset Management Software Integration", desc: "Cloud register deployment, scanner setup & maintenance scheduling" },
  { id: "reorganize", name: "Store & Warehouse Reorganization", desc: "Physical inventory sorting, racking optimization & labeling" },
  { id: "data", name: "Data Entry & Document Archiving", desc: "Digitization of paper invoices, purchase orders & fixed asset schedules" }
];

export default function QuoteCalculator() {
  const [selectedService, setSelectedService] = useState("full");
  const [selectedMaterial, setSelectedMaterial] = useState("anodised");
  const [assetCount, setAssetCount] = useState(500);
  const [branches, setBranches] = useState(1);
  const [tagTechnology, setTagTechnology] = useState("Barcode + QR Code");
  const [name, setName] = useState("");
  const [company, setCompany] = useState("");
  const [phone, setPhone] = useState("");
  const [email, setEmail] = useState("");
  const [notes, setNotes] = useState("");
  const [submitted, setSubmitted] = useState(false);

  function handleSubmit(e) {
    e.preventDefault();
    const serviceName = SERVICES.find(s => s.id === selectedService)?.name || selectedService;
    const materialName = MATERIALS.find(m => m.id === selectedMaterial)?.name || selectedMaterial;

    const emailSubject = `Quote Request: ${company || name || "New Client"} - ${assetCount} Assets`;
    const emailBody = `O.CUBE ASSET MANAGEMENT - QUOTE INQUIRY

Contact Information:
--------------------
Full Name: ${name}
Company Name: ${company}
Phone Number: ${phone}
Email Address: ${email}

Project Scope:
--------------
Service Required: ${serviceName}
Estimated Asset Count: ${assetCount} items
Number of Operating Locations / Branches: ${branches}
Preferred Tag Material: ${materialName}
Tag Technology: ${tagTechnology}

Special Requirements / Site Notes:
----------------------------------
${notes || "None provided."}

Submitted via O.Cube Interactive Quote Estimator.`;

    window.location.href = `mailto:ocubeasset@gmail.com?cc=olawale_olowogoke@yahoo.co.uk&subject=${encodeURIComponent(emailSubject)}&body=${encodeURIComponent(emailBody)}`;
    setSubmitted(true);
  }

  return (
    <section id="quote-calculator" className={styles.section}>
      <div className={`wrap ${styles.container}`}>
        <div className={styles.header}>
          <span className={styles.badge}>Interactive Cost & Scope Estimator</span>
          <h2 className={styles.title}>Configure Your Asset Project & Get an Instant Quote</h2>
          <p className={styles.subtitle}>
            Select your service type, estimated asset volume, and label specifications below. Our asset specialists will prepare an itemized proposal with accurate timelines.
          </p>
        </div>

        <form className={styles.calculatorCard} onSubmit={handleSubmit}>
          {/* Step 1: Service Type */}
          <div className={styles.stepBlock}>
            <div className={styles.stepTitle}>
              <span className={styles.stepNum}>1</span>
              <h3>Select Service Scope</h3>
            </div>
            <div className={styles.serviceGrid}>
              {SERVICES.map((s) => (
                <button
                  type="button"
                  key={s.id}
                  className={`${styles.serviceBtn} ${selectedService === s.id ? styles.activeService : ""}`}
                  onClick={() => setSelectedService(s.id)}
                >
                  <span className={styles.radioDot} />
                  <div>
                    <strong>{s.name}</strong>
                    <p>{s.desc}</p>
                  </div>
                </button>
              ))}
            </div>
          </div>

          {/* Step 2: Scale & Quantity */}
          <div className={styles.stepBlock}>
            <div className={styles.stepTitle}>
              <span className={styles.stepNum}>2</span>
              <h3>Estimated Quantity & Locations</h3>
            </div>
            <div className={styles.sliderGrid}>
              <div className={styles.sliderBox}>
                <div className={styles.sliderLabel}>
                  <span>Approximate Number of Assets:</span>
                  <strong>{Number(assetCount).toLocaleString()} items</strong>
                </div>
                <input
                  type="range"
                  min="50"
                  max="10000"
                  step="50"
                  value={assetCount}
                  onChange={(e) => setAssetCount(Number(e.target.value))}
                  className={styles.rangeSlider}
                />
                <div className={styles.rangeScale}>
                  <span>50</span>
                  <span>1,000</span>
                  <span>5,000</span>
                  <span>10,000+</span>
                </div>
              </div>

              <div className={styles.sliderBox}>
                <div className={styles.sliderLabel}>
                  <span>Number of Sites / Branches:</span>
                  <strong>{branches} {branches === 1 ? "Location" : "Locations"}</strong>
                </div>
                <input
                  type="range"
                  min="1"
                  max="20"
                  step="1"
                  value={branches}
                  onChange={(e) => setBranches(Number(e.target.value))}
                  className={styles.rangeSlider}
                />
                <div className={styles.rangeScale}>
                  <span>1 Single Site</span>
                  <span>5 Branches</span>
                  <span>10 Sites</span>
                  <span>20+ Nationwide</span>
                </div>
              </div>
            </div>
          </div>

          {/* Step 3: Material & Symbology */}
          <div className={styles.stepBlock}>
            <div className={styles.stepTitle}>
              <span className={styles.stepNum}>3</span>
              <h3>Tag Material & Symbology</h3>
            </div>
            <div className={styles.materialGrid}>
              {MATERIALS.map((m) => (
                <div
                  key={m.id}
                  className={`${styles.materialCard} ${selectedMaterial === m.id ? styles.activeMaterial : ""}`}
                  onClick={() => setSelectedMaterial(m.id)}
                >
                  <div className={styles.materialHeader}>
                    <strong>{m.name}</strong>
                    <span className={styles.durabilityPill}>{m.durability}</span>
                  </div>
                  <p>{m.desc}</p>
                </div>
              ))}
            </div>

            <div className={styles.techSelection}>
              <label>Scanning Symbology:</label>
              <div className={styles.techPills}>
                {["1D Barcode (Code 128)", "2D QR Code", "Barcode + QR Code", "RFID Ultra-High Frequency (UHF)"].map((t) => (
                  <button
                    type="button"
                    key={t}
                    className={`${styles.techBtn} ${tagTechnology === t ? styles.activeTech : ""}`}
                    onClick={() => setTagTechnology(t)}
                  >
                    {t}
                  </button>
                ))}
              </div>
            </div>
          </div>

          {/* Step 4: Contact Information */}
          <div className={styles.stepBlock}>
            <div className={styles.stepTitle}>
              <span className={styles.stepNum}>4</span>
              <h3>Your Contact Information</h3>
            </div>
            <div className={styles.contactFields}>
              <label>
                Full Name *
                <input
                  type="text"
                  required
                  placeholder="e.g. Olawale Olowogoke"
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                />
              </label>

              <label>
                Company / Organization Name *
                <input
                  type="text"
                  required
                  placeholder="e.g. Eat 'N' GO, Jumia, Dangote..."
                  value={company}
                  onChange={(e) => setCompany(e.target.value)}
                />
              </label>

              <label>
                Phone Number (WhatsApp) *
                <input
                  type="tel"
                  required
                  placeholder="+234 ..."
                  value={phone}
                  onChange={(e) => setPhone(e.target.value)}
                />
              </label>

              <label>
                Corporate Email Address *
                <input
                  type="email"
                  required
                  placeholder="name@company.com"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                />
              </label>

              <label className={styles.fullWidthField}>
                Additional Notes or Specific Instructions:
                <textarea
                  rows="3"
                  placeholder="Describe your asset types (laptops, industrial pumps, cold storage racks, vehicles), current asset register condition, or preferred timelines..."
                  value={notes}
                  onChange={(e) => setNotes(e.target.value)}
                />
              </label>
            </div>
          </div>

          {/* Submission Bar */}
          <div className={styles.submitBar}>
            <div className={styles.summaryDigest}>
              <span>Summary:</span>
              <strong>{Number(assetCount).toLocaleString()} Assets · {branches} Site(s) · {MATERIALS.find(m => m.id === selectedMaterial)?.name.split(' ')[0]} Tag</strong>
            </div>

            <button type="submit" className="btn">
              Generate & Send Quotation Request →
            </button>
          </div>

          {submitted && (
            <div className={styles.successMessage}>
              <span className={styles.checkIcon}>✓</span>
              <div>
                <strong>Inquiry Form Dispatched!</strong>
                <p>Your mail application has opened with all project parameters pre-filled. You can also reach our principal team directly at <strong>+234 805 526 0304</strong> or <strong>+234 808 144 4046</strong>.</p>
              </div>
            </div>
          )}
        </form>
      </div>
    </section>
  );
}
