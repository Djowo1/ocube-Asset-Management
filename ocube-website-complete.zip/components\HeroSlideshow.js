"use client";
import { useState, useEffect, useRef } from "react";
import Image from "next/image";
import Link from "next/link";
import CubeAnimation from "./CubeAnimation";
import styles from "./HeroSlideshow.module.css";

const SLIDES = [
  {
    badge: "Official Asset Management Partner",
    title: "Know Every Asset You Own.",
    subtitle: "From industrial machinery to corporate IT and fleet vehicles — we deliver 100% visibility, audit readiness, and physical accountability across Nigeria.",
    ctaPrimary: "Request a Free Quote",
    ctaPrimaryLink: "/contact",
    ctaSecondary: "Explore Our Tags",
    ctaSecondaryLink: "/#tags",
    stats: [
      { num: "100%", label: "Audit Readiness" },
      { num: "10+", label: "Years Experience" },
      { num: "0%", label: "Ghost Asset Tolerance" }
    ],
    showCube: true,
    image: "/uploaded/media_1794340137739_184d4454.jpg",
    imageAlt: "Heavy Caterpillar Industrial Machinery Tagged on Site"
  },
  {
    badge: "Field Tagging & Industrial Verification",
    title: "Heavy Equipment, Machinery & Cold Stores.",
    subtitle: "Engineered barcode, QR, and tamper-evident asset tags built to withstand severe heat, weather, abrasion, and industrial environments.",
    ctaPrimary: "View Tag Materials",
    ctaPrimaryLink: "/#tags",
    ctaSecondary: "Download Profile",
    ctaSecondaryLink: "/OCube-Company-Profile.pdf",
    stats: [
      { num: "005", label: "Anodised Alum" },
      { num: "3M", label: "Laminated Polyester" },
      { num: "Silver", label: "Tamper Void" }
    ],
    showCube: false,
    image: "/uploaded/media_1794340137857_b5172962.jpg",
    imageAlt: "Cold storage warehouse shelving verified and tagged"
  },
  {
    badge: "Logistics, Fleets & Multi-Branch Facilities",
    title: "Fleet Bikes, Delivery Boxes & Corporate Assets.",
    subtitle: "Trusted by prominent brands including Eat 'N' GO, Dangote Sugar Refinery Plc, United Bank for Africa (UBA), Jumia, and Lagos State Government projects.",
    ctaPrimary: "Book Physical Audit",
    ctaPrimaryLink: "/contact",
    ctaSecondary: "Watch Project Video",
    ctaSecondaryLink: "/#video-showcase",
    stats: [
      { num: "RC", label: "1247860 Incorporated" },
      { num: "Multi", label: "Location Audits" },
      { num: "Fast", label: "Turnaround Time" }
    ],
    showCube: false,
    image: "/uploaded/media_1794340137764_70a7656d.jpg",
    imageAlt: "Eat N GO delivery motorcycle fleet tagged on chassis"
  }
];

export default function HeroSlideshow() {
  const [current, setCurrent] = useState(0);
  const [isPaused, setIsPaused] = useState(false);
  const touchStartX = useRef(0);

  useEffect(() => {
    if (isPaused) return;
    const timer = setInterval(() => {
      setCurrent((prev) => (prev + 1) % SLIDES.length);
    }, 6500);
    return () => clearInterval(timer);
  }, [isPaused]);

  function handleTouchStart(e) {
    touchStartX.current = e.touches[0].clientX;
  }

  function handleTouchEnd(e) {
    const diff = touchStartX.current - e.changedTouches[0].clientX;
    if (diff > 50) {
      setCurrent((prev) => (prev + 1) % SLIDES.length);
    } else if (diff < -50) {
      setCurrent((prev) => (prev - 1 + SLIDES.length) % SLIDES.length);
    }
  }

  const slide = SLIDES[current];

  return (
    <section
      className={styles.heroSection}
      onMouseEnter={() => setIsPaused(true)}
      onMouseLeave={() => setIsPaused(false)}
      onTouchStart={handleTouchStart}
      onTouchEnd={handleTouchEnd}
      aria-roledescription="carousel"
      aria-label="O.Cube Highlight Slideshow"
    >
      {/* Background Slides */}
      <div className={styles.bgContainer}>
        {SLIDES.map((s, idx) => (
          <div
            key={idx}
            className={`${styles.bgSlide} ${idx === current ? styles.activeBg : ""}`}
            style={{ backgroundImage: `url(${s.image})` }}
          >
            <div className={styles.bgOverlay} />
            <div className={styles.meshGradients} />
          </div>
        ))}
      </div>

      <div className={`wrap ${styles.heroContainer}`}>
        {/* Left Column: Text & CTAs */}
        <div className={styles.copyCol}>
          <div className={styles.badgeRow}>
            <span className={styles.statusDot} />
            <span className={styles.badgeText}>{slide.badge}</span>
          </div>

          <h1 className={styles.headline} key={`title-${current}`}>
            {slide.title}
          </h1>

          <p className={styles.subtitle} key={`sub-${current}`}>
            {slide.subtitle}
          </p>

          <div className={styles.actionRow}>
            <Link href={slide.ctaPrimaryLink} className="btn">
              {slide.ctaPrimary}
            </Link>
            <Link href={slide.ctaSecondaryLink} className="btn ghost">
              {slide.ctaSecondary}
            </Link>
          </div>

          {/* Key Stat Badges */}
          <div className={styles.statsRow}>
            {slide.stats.map((st, i) => (
              <div key={i} className={styles.statBox}>
                <span className={styles.statNum}>{st.num}</span>
                <span className={styles.statLbl}>{st.label}</span>
              </div>
            ))}
          </div>
        </div>

        {/* Right Column: 3D Cube / Live Feature Display */}
        <div className={styles.visualCol}>
          {slide.showCube ? (
            <div className={styles.cubeCard}>
              <div className={styles.cubeCardHeader}>
                <span className={styles.cubeTagPill}>INTERACTIVE 3D PROTOTYPE</span>
                <span className={styles.cubeHintText}>360° GEOMETRY</span>
              </div>
              <CubeAnimation size={170} />
              <div className={styles.cubeCardFooter}>
                <p><strong>O.CUBE Asset Management Limited</strong></p>
                <small>RC 1247860 · Verification · Tagging · Software</small>
              </div>
            </div>
          ) : (
            <div className={styles.featureImageCard}>
              <div className={styles.imageWrapper}>
                <Image
                  src={slide.image}
                  alt={slide.imageAlt}
                  width={580}
                  height={420}
                  priority
                  className={styles.featureImg}
                />
                <div className={styles.imageBadge}>
                  <span>VERIFIED FIELD DEPLOYMENT</span>
                </div>
              </div>
              <div className={styles.imageCaption}>
                <p>{slide.imageAlt}</p>
              </div>
            </div>
          )}
        </div>
      </div>

      {/* Slide Navigation Controls */}
      <div className={styles.navBar}>
        <div className={styles.dots}>
          {SLIDES.map((_, idx) => (
            <button
              key={idx}
              className={`${styles.dot} ${idx === current ? styles.activeDot : ""}`}
              onClick={() => setCurrent(idx)}
              aria-label={`Go to slide ${idx + 1}`}
            />
          ))}
        </div>
        <div className={styles.arrows}>
          <button
            onClick={() => setCurrent((prev) => (prev - 1 + SLIDES.length) % SLIDES.length)}
            aria-label="Previous Slide"
            className={styles.arrowBtn}
          >
            ←
          </button>
          <span className={styles.slideCounter}>
            0{current + 1} / 0{SLIDES.length}
          </span>
          <button
            onClick={() => setCurrent((prev) => (prev + 1) % SLIDES.length)}
            aria-label="Next Slide"
            className={styles.arrowBtn}
          >
            →
          </button>
        </div>
      </div>
    </section>
  );
}
