# O. Cube Asset Management website

Next.js 14 (App Router), React 18, JavaScript, CSS Modules, mobile-first.

## Run locally
1. Install Node.js 18.17+ (https://nodejs.org) and confirm with `node -v`.
2. In this folder: `npm install`
3. `npm run dev` then open http://localhost:3000
4. Production check: `npm run build && npm start`

Dependencies (installed by npm install): next 14.2.15, react 18.3.1, react-dom 18.3.1. The font (Plus Jakarta Sans) downloads at build time, so be online on first run.

## Deploy to Netlify
Push to GitHub, then Netlify > Add new site > Import. Build command `npm run build`. Netlify detects Next.js automatically (`netlify.toml` included).

## Edit
- Copy and sections: `app/page.js`; colours: `:root` in `app/globals.css`
- Contact details: `components/Footer.js` and `app/contact/page.js`
- Images: `public/img/` (WebP, already compressed)
- Enquiry form opens the visitor's email app addressed to ocubeasset@gmail.com. Swap `components/EnquiryForm.js` for Netlify Forms/Formspree for server-side delivery.
