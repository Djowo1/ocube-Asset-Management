"use client";
import { useState, useRef } from "react";
import styles from "./VideoShowcase.module.css";

export default function VideoShowcase() {
  const [isPlaying, setIsPlaying] = useState(false);
  const [isMuted, setIsMuted] = useState(true);
  const videoRef = useRef(null);

  function togglePlay() {
    if (!videoRef.current) return;
    if (isPlaying) {
      videoRef.current.pause();
      setIsPlaying(false);
    } else {
      videoRef.current.play();
      setIsPlaying(true);
    }
  }

  function toggleMute() {
    if (!videoRef.current) return;
    videoRef.current.muted = !isMuted;
    setIsMuted(!isMuted);
  }

  return (
    <section id="video-showcase" className={styles.section}>
      <div className={`wrap ${styles.container}`}>
        <div className={styles.header}>
          <span className={styles.eyebrow}>Live On-Site Video Walkthrough</span>
          <h2 className={styles.heading}>See Our Physical Asset Verification in Action</h2>
          <p className={styles.desc}>
            Watch our field operations team inspect, tag, record, and reconcile physical enterprise assets in real operating environments.
          </p>
        </div>

        <div className={styles.videoPlayerCard}>
          <div className={styles.videoWrapper} onClick={togglePlay}>
            <video
              ref={videoRef}
              src="/ocube-video.mp4"
              playsInline
              muted={isMuted}
              loop
              className={styles.video}
              onPlay={() => setIsPlaying(true)}
              onPause={() => setIsPlaying(false)}
            />

            {!isPlaying && (
              <div className={styles.playOverlay}>
                <button
                  className={styles.playBtn}
                  onClick={(e) => {
                    e.stopPropagation();
                    togglePlay();
                  }}
                  aria-label="Play Video"
                >
                  ▶
                </button>
                <span className={styles.playPrompt}>Click to Watch Video</span>
              </div>
            )}

            <div className={styles.videoControls} onClick={(e) => e.stopPropagation()}>
              <button
                onClick={togglePlay}
                className={styles.controlPill}
                aria-label={isPlaying ? "Pause" : "Play"}
              >
                {isPlaying ? "❚❚ Pause" : "▶ Play"}
              </button>
              <button
                onClick={toggleMute}
                className={styles.controlPill}
                aria-label={isMuted ? "Unmute" : "Mute"}
              >
                {isMuted ? "🔇 Unmute" : "🔊 Mute"}
              </button>
              <span className={styles.videoTagBadge}>
                FIELD VERIFICATION EXERCISE
              </span>
            </div>
          </div>

          <div className={styles.videoFooter}>
            <div className={styles.footerCol}>
              <h4>Physical Count & Barcode Labeling</h4>
              <p>Each asset is systematically cleaned, affixed with resilient tamper-evident / anodised tags, and recorded directly to the register.</p>
            </div>
            <div className={styles.footerCol}>
              <h4>Reconciliation & Discrepancy Elimination</h4>
              <p>Ensuring your physical floor assets match your financial balance sheet and general ledger with 100% accuracy.</p>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
