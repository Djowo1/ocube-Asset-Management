"use client";
import { useState, useEffect } from "react";
import styles from "./CubeAnimation.module.css";

export default function CubeAnimation({ interactive = true, size = 160 }) {
  const [rotX, setRotX] = useState(-24);
  const [rotY, setRotY] = useState(38);
  const [isHovered, setIsHovered] = useState(false);
  const [isDragging, setIsDragging] = useState(false);
  const [startPos, setStartPos] = useState({ x: 0, y: 0 });

  useEffect(() => {
    if (isDragging || isHovered) return;
    const interval = setInterval(() => {
      setRotY((prev) => (prev + 0.5) % 360);
      setRotX((prev) => -20 + Math.sin(Date.now() / 1500) * 8);
    }, 30);
    return () => clearInterval(interval);
  }, [isDragging, isHovered]);

  function handlePointerDown(e) {
    if (!interactive) return;
    setIsDragging(true);
    setStartPos({ x: e.clientX, y: e.clientY });
  }

  function handlePointerMove(e) {
    if (!isDragging || !interactive) return;
    const dx = e.clientX - startPos.x;
    const dy = e.clientY - startPos.y;
    setRotY((prev) => prev + dx * 0.4);
    setRotX((prev) => Math.max(-60, Math.min(60, prev - dy * 0.4)));
    setStartPos({ x: e.clientX, y: e.clientY });
  }

  function handlePointerUp() {
    setIsDragging(false);
  }

  const half = size / 2;

  return (
    <div
      className={styles.cubeContainer}
      style={{ width: size, height: size }}
      onPointerDown={handlePointerDown}
      onPointerMove={handlePointerMove}
      onPointerUp={handlePointerUp}
      onPointerLeave={() => {
        setIsDragging(false);
        setIsHovered(false);
      }}
      onPointerEnter={() => setIsHovered(true)}
      title="Interactive 3D O.Cube - Drag to rotate"
      role="img"
      aria-label="3D O.Cube Asset Geometry"
    >
      <div
        className={styles.cubeScene}
        style={{
          transform: `rotateX(${rotX}deg) rotateY(${rotY}deg)`,
        }}
      >
        {/* Front Face: O.CUBE brand */}
        <div
          className={`${styles.face} ${styles.front}`}
          style={{ transform: `translateZ(${half}px)` }}
        >
          <div className={styles.innerPattern}>
            <span className={styles.cubeBrand}>O.CUBE</span>
            <div className={styles.gridMini}>
              <span className={styles.cellGold} />
              <span className={styles.cellBlue} />
              <span className={styles.cellBlue} />
              <span className={styles.cellGold} />
            </div>
            <small>VERIFIED</small>
          </div>
        </div>

        {/* Back Face: Asset Tag */}
        <div
          className={`${styles.face} ${styles.back}`}
          style={{ transform: `rotateY(180deg) translateZ(${half}px)` }}
        >
          <div className={styles.innerTag}>
            <div className={styles.tagHead}>ASSET TAG</div>
            <div className={styles.barLines}>
              <span /><span /><span /><span /><span /><span /><span /><span />
            </div>
            <div className={styles.tagCode}>RC-1247860</div>
          </div>
        </div>

        {/* Right Face: QR Matrix */}
        <div
          className={`${styles.face} ${styles.right}`}
          style={{ transform: `rotateY(90deg) translateZ(${half}px)` }}
        >
          <div className={styles.innerQr}>
            <div className={styles.qrCorner} />
            <div className={styles.qrCorner} />
            <div className={styles.qrCorner} />
            <div className={styles.qrDot} />
            <small>RFID / QR</small>
          </div>
        </div>

        {/* Left Face: Tag Materials */}
        <div
          className={`${styles.face} ${styles.left}`}
          style={{ transform: `rotateY(-90deg) translateZ(${half}px)` }}
        >
          <div className={styles.innerList}>
            <b>TAG TECH</b>
            <span>• 3M LAMINATE</span>
            <span>• 005 ALUM</span>
            <span>• SILVER VOID</span>
          </div>
        </div>

        {/* Top Face: Accent Yellow/Gold */}
        <div
          className={`${styles.face} ${styles.top}`}
          style={{ transform: `rotateX(90deg) translateZ(${half}px)` }}
        >
          <div className={styles.goldLuster}>
            <span>TOTAL CONTROL</span>
          </div>
        </div>

        {/* Bottom Face: Deep Foundation */}
        <div
          className={`${styles.face} ${styles.bottom}`}
          style={{ transform: `rotateX(-90deg) translateZ(${half}px)` }}
        >
          <div className={styles.darkBase} />
        </div>
      </div>
      <div className={styles.shadow} />
      <span className={styles.hint}>Drag to rotate</span>
    </div>
  );
}

