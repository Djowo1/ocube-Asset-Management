"use client";
import { useEffect, useState } from "react";
import Logo from "./Logo";
import s from "./Loader.module.css";
export default function Loader() {
  const [phase, setPhase] = useState(0);
  useEffect(() => {
    const a = setTimeout(() => setPhase(1), 1300);
    const b = setTimeout(() => setPhase(2), 2000);
    return () => { clearTimeout(a); clearTimeout(b); };
  }, []);
  if (phase === 2) return null;
  return (
    <div className={`${s.l} ${phase ? s.out : ""}`} aria-hidden="true">
      <div className={s.mark}><Logo size={72} text={false} /></div>
      <div className={s.bar}><i /></div>
    </div>
  );
}
