import { Plus_Jakarta_Sans } from "next/font/google";
import "./globals.css";
import Loader from "@/components/Loader";
import Header from "@/components/Header";
import Footer from "@/components/Footer";

const font = Plus_Jakarta_Sans({ subsets: ["latin"], display: "swap", variable: "--font" });

export const metadata = {
  title: "O. Cube Asset Management | Asset Verification, Tagging & Reconciliation",
  description: "Fixed asset verification, barcode/QR/RFID tagging, reconciliation and asset management software for businesses, government, schools and hospitals in Nigeria.",
};
export const viewport = { themeColor: "#081447", width: "device-width", initialScale: 1 };

export default function RootLayout({ children }) {
  return (
    <html lang="en" className={font.variable}>
      <body>
        <Loader />
        <Header />
        <main>{children}</main>
        <Footer />
      </body>
    </html>
  );
}
