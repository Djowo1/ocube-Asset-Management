"use client";
import Image from "next/image";
import Link from "next/link";
import HeroSlideshow from "@/components/HeroSlideshow";
import InteractiveCarousel from "@/components/InteractiveCarousel";
import QuoteCalculator from "@/components/QuoteCalculator";
import CubeAnimation from "@/components/CubeAnimation";
import Reveal from "@/components/Reveal";
import s from "./page.module.css";

// 100% Genuine Field Work Photos (No screenshots, no chats, no third-party websites)
const FIELD_ITEMS = [
  {
    src: "/img/field/eatngo-motorbike.jpg",
    title: "Commercial Delivery Fleet Motorbikes",
    category: "Fleet & Logistics",
    code: "OPMV1001414",
    desc: "Weatherproof barcode tagging on chassis frame of delivery motorbikes for real-time fleet maintenance and tracking."
  },
  {
    src: "/img/field/caterpillar-generator.jpg",
    title: "Caterpillar Heavy Generator & Control Panel",
    category: "Heavy Plant Equipment",
    code: "DPEQ1000613",
    desc: "Chemical and heat-resistant anodised plate installed on Caterpillar standby power generating plant."
  },
  {
    src: "/img/field/coldroom-racks.jpg",
    title: "Industrial Cold Room Wire Shelving",
    category: "Warehousing & Storage",
    code: "DPKE2001269",
    desc: "Sub-zero adhesive asset tags for industrial cold storage wire racks holding food inventory."
  },
  {
    src: "/img/field/commercial-furniture.jpg",
    title: "Commercial Dining & Facility Tables",
    category: "Corporate Hospitality",
    code: "DFUR1004521",
    desc: "Discrete tamper-proof identification on metal underframes for corporate and restaurant multi-unit branches."
  },
  {
    src: "/img/field/hvac-air-conditioner.jpg",
    title: "Commercial HVAC Air Conditioning Units",
    category: "Facility Management",
    code: "DPAC1000622",
    desc: "Outdoor-grade UV resistant asset tag on commercial split and package air-conditioning units."
  },
  {
    src: "/img/field/dispatch-top-box.jpg",
    title: "Dispatch Delivery Top Boxes",
    category: "Logistics Equipment",
    code: "DPMV1001352",
    desc: "Asset identification on insulated fiberglass motorcycle delivery boxes certified for urban dispatch."
  },
  {
    src: "/img/field/restaurant-high-table.jpg",
    title: "Facility High Tables & Stools",
    category: "Hospitality & Corporate",
    code: "DFUR1004530",
    desc: "Durable barcode labeling applied to steel frame bases for corporate branches."
  }
];

// 100% Genuine Physical Tag Samples (Clean photos of tags)
const TAG_ITEMS = [
  {
    src: "/img/tags/dangote-metal-tag.jpg",
    title: "Dangote Sugar Refinery Plc",
    material: "005 Anodised Aluminium Barcode Plate",
    code: "3100000204.66667",
    desc: "Heavy industrial aluminium plate with deep-etched barcode and corporate logo. Resists acid, solvents, and high temperatures."
  },
  {
    src: "/img/tags/allied-anodised-003.jpg",
    title: "Allied Restoration (003 Anodised)",
    material: "003 Anodised Aluminium + 2D Datamatrix",
    code: "832.1 (844-9-ALLIED)",
    desc: "High density 2D data-matrix on anodised metal for compact asset labeling and fast scanner reading."
  },
  {
    src: "/img/tags/uba-silver-void.jpg",
    title: "United Bank for Africa (UBA)",
    material: "Silver Void Polyester Laminated",
    code: "0166/EMT/FF/1850001/0570",
    desc: "Tamper-evident security label. Leaves indelible 'VOID' adhesive layer on surface if unauthorized removal is attempted."
  },
  {
    src: "/img/tags/green-hills-qr.jpg",
    title: "Green Hills Agricultural Products",
    material: "Polypropylene Standard Lamination",
    code: "GHAP/PMTE/0282-0284",
    desc: "Waterproof synthetic label featuring corporate logo and 2D QR code for agricultural asset registers."
  },
  {
    src: "/img/tags/usaed-anodised-005.jpg",
    title: "US Government Property (USAED Omaha)",
    material: "005 Anodised Aluminium Heavy Duty",
    code: "USAED Omaha 0007V / 0008V",
    desc: "Military & federal grade metal tag with barcode and emblem for mission-critical asset accountability."
  },
  {
    src: "/img/tags/miller-foods-metal.jpg",
    title: "Miller Foods (RM) Limited",
    material: "Brushed Aluminium Metal Barcode Tag",
    code: "GB105157",
    desc: "Clean-edge metallic finish designed for food processing machinery, stainless steel vessels, and cleanroom facilities."
  },
  {
    src: "/img/tags/lmdgp-silver-void.jpg",
    title: "Lagos Metropolitan Development Project",
    material: "Silver Void Polyester Laminated (LMDGP)",
    code: "LMDGP/MV/0022 - 0024",
    desc: "Official state development governance project tags for public infrastructure and municipal mobile assets."
  },
  {
    src: "/img/tags/nfc-barcode.jpg",
    title: "Property of NFZ Barcode Tag",
    material: "Durable Polyester Asset Label",
    code: "NFZ/FF/00290",
    desc: "High-contrast linear Code 128 barcode label engineered for rapid optical scanning and register reconciliation."
  },
  {
    src: "/img/tags/cvcnu-3m-polyester.jpg",
    title: "Committee of Vice-Chancellors (CVCNU)",
    material: "3M Polyester 100% Laminated",
    code: "FF0591 - FF0593",
    desc: "Educational institution asset tags engineered with high-tack acrylic adhesive and durable overlaminate."
  }
];

const SERVICES_DATA = [
  {
    num: "01",
    title: "Fixed Asset Verification",
    badge: "Core Service",
    desc: "Comprehensive physical verification across multiple offices, branches, and plant locations. We physically confirm the existence, condition, GPS location, and custodianship of every capital asset.",
    bullets: ["Zero ghost asset tolerance", "Detailed physical condition audit", "Custodianship validation"]
  },
  {
    num: "02",
    title: "Asset Tagging & Identification",
    badge: "Specialized Hardware",
    desc: "Custom barcode, QR code, and RFID tags manufactured in 005 anodised aluminium, 3M laminated polyester, or silver void tamper-evident substrates, branded with your corporate logo.",
    bullets: ["Anodised aluminium & 3M polyester", "Unique serialized barcodes & QRs", "RFID UHF integration"]
  },
  {
    num: "03",
    title: "Asset Register Reconciliation",
    badge: "Financial Integrity",
    desc: "We reconcile physical audit findings against your general ledger and historical balance sheet. Gaps, missing items, unrecorded purchases, and write-offs are systematically resolved.",
    bullets: ["Variance analysis & reporting", "General ledger alignment", "IFRS & statutory audit readiness"]
  },
  {
    num: "04",
    title: "Asset Management Software",
    badge: "Cloud Technology",
    desc: "Centralized platform for end-to-end asset lifecycle control: scanner check-in/out, depreciation calculations, preventative maintenance schedules, and multi-location dashboards.",
    bullets: ["Real-time asset movement tracking", "Depreciation & lifecycle logs", "Instant audit-ready export"]
  },
  {
    num: "05",
    title: "Store & Warehouse Reorganization",
    badge: "Operations",
    desc: "Transform congested, inefficient storerooms into structured, logical environments. We sort stock, implement bin/shelf labeling, categorize parts, and eliminate slow-moving bottlenecks.",
    bullets: ["Shelving & bin identification", "Layout flow optimization", "Obsolete stock segregation"]
  },
  {
    num: "06",
    title: "Data Entry & Digitization",
    badge: "Record Keeping",
    desc: "Rapid conversion of manual ledgers, paper delivery notes, equipment invoices, and scattered spreadsheets into clean, normalized digital databases with strict quality controls.",
    bullets: ["High-speed accurate data capture", "Database cleansing & normalization", "Secure confidential processing"]
  },
  {
    num: "07",
    title: "Document Archiving & EDMS",
    badge: "Compliance",
    desc: "Professional scanning, metadata indexing, and structured electronic archiving of asset procurement files, deeds, warranty certificates, and maintenance history documents.",
    bullets: ["Indexed electronic document archive", "Fast keyword file retrieval", "Audit compliance retention"]
  }
];

const INDUSTRIES_DATA = [
  { icon: "🏛️", title: "Government Agencies", desc: "Federal & State ministries, MDAs, and municipal infrastructure projects." },
  { icon: "🏦", title: "Financial Institutions", desc: "Commercial banks, fintechs, insurance & microfinance branches." },
  { icon: "🏭", title: "Manufacturing & FMCG", desc: "Sugar refineries, bottling plants, assembly lines & industrial equipment." },
  { icon: "🛵", title: "Logistics & Fleets", desc: "Quick-service restaurant delivery bikes, haulage & dispatch fleets." },
  { icon: "🎓", title: "Educational Institutions", desc: "Universities, campus laboratories, research ICT centers & lecture halls." },
  { icon: "🏥", title: "Healthcare & Hospitals", desc: "Medical diagnostic equipment, specialized clinic tools & ward furniture." },
  { icon: "📡", title: "Telecommunications", desc: "Cellular masts, base stations, server racks & power equipment." },
  { icon: "🌐", title: "Non-Governmental (NGOs)", desc: "International aid agencies, donor-funded assets & regional mission offices." }
];

export default function Home() {
  return (
    <>
      {/* 1. Dynamic Hero Slideshow with 3D O.Cube */}
      <HeroSlideshow />

      {/* 2. Client Trust Strip with Registered Entity Credentials */}
      <section className={s.trustBar}>
        <div className={`wrap ${s.trustGrid}`}>
          <div className={s.trustItem}>
            <span className={s.trustPill}>CAC REGISTRATION</span>
            <strong>RC 1247860</strong>
            <small>Incorporated 11th March, 2015</small>
          </div>
          <div className={s.trustItem}>
            <span className={s.trustPill}>TRACK RECORD</span>
            <strong>100,000+ Assets</strong>
            <small>Verified, Tagged & Reconciled</small>
          </div>
          <div className={s.trustItem}>
            <span className={s.trustPill}>ACCURACY RATE</span>
            <strong>99.98%</strong>
            <small>Zero Ghost Asset Variance</small>
          </div>
          <div className={s.trustItem}>
            <span className={s.trustPill}>COVERAGE</span>
            <strong>Nationwide Nigeria</strong>
            <small>Lagos, Abuja, Port Harcourt & Beyond</small>
          </div>
        </div>
      </section>

      {/* 3. Interactive 3D Cube Feature Section */}
      <section id="interactive-cube" className={s.cubeFeatureSection}>
        <div className={`wrap ${s.cubeFeatureGrid}`}>
          <div className={s.cubeFeatureCopy}>
            <Reveal>
              <span className={s.subBadge}>The O.CUBE Advantage</span>
              <h2>Total Visibility. Engineered Geometry. Full Accountability.</h2>
              <p className={s.leadText}>
                Just as each face of a cube locks into perfect alignment, our systematic asset management framework connects physical field counts, durable barcode/RFID tagging, and live software registers into one seamless source of truth.
              </p>
              <ul className={s.featureChecklist}>
                <li><strong>Excellence:</strong> Military-grade 005 aluminium tags and tamper-evident materials that never peel.</li>
                <li><strong>Integrity:</strong> Independent physical audits that eliminate phantom assets and balance sheet errors.</li>
                <li><strong>Innovation:</strong> QR, Datamatrix, and RFID technology linked directly to our cloud asset software.</li>
              </ul>
              <div className={s.cubeCtas}>
                <Link href="#quote-calculator" className="btn">Configure Your Project</Link>
                <a href="/OCube-Company-Profile.pdf" download className="btn ghost">Download Profile PDF</a>
              </div>
            </Reveal>
          </div>

          <div className={s.cubeFeatureVisual}>
            <div className={s.cubeDisplayPlate}>
              <div className={s.cubeBadgeTop}>
                <span>3D ASSET CUBE</span>
                <span>DRAG & ROTATE</span>
              </div>
              <CubeAnimation size={210} />
              <div className={s.cubeStatsMini}>
                <div><strong>005</strong><small>Anodised</small></div>
                <div><strong>3M</strong><small>Laminate</small></div>
                <div><strong>UHF</strong><small>RFID</small></div>
                <div><strong>100%</strong><small>Audit Ready</small></div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* 4. Core Services (Detailed Grid) */}
      <section id="services" className={s.servicesSection}>
        <div className="wrap">
          <Reveal>
            <div className={s.secHeader}>
              <span className={s.subBadge}>End-To-End Methodology</span>
              <h2>What We Do for Your Organization</h2>
              <p className={s.leadText}>
                From the very first on-site physical count to an active, audit-proof electronic register, O.CUBE delivers turnkey asset governance.
              </p>
            </div>
          </Reveal>

          <div className={s.serviceCards}>
            {SERVICES_DATA.map((srv, idx) => (
              <Reveal key={srv.num} delay={idx * 60}>
                <article className={`${s.serviceCard} ${idx === 0 ? s.featuredCard : ""}`}>
                  <div className={s.cardTop}>
                    <span className={s.serviceNum}>{srv.num}</span>
                    <span className={s.serviceBadge}>{srv.badge}</span>
                  </div>
                  <h3>{srv.title}</h3>
                  <p className={s.serviceDesc}>{srv.desc}</p>
                  <ul className={s.serviceBullets}>
                    {srv.bullets.map((b, i) => (
                      <li key={i}>{b}</li>
                    ))}
                  </ul>
                  <Link href="#quote-calculator" className={s.serviceLink}>
                    Inquire for this service →
                  </Link>
                </article>
              </Reveal>
            ))}
          </div>
        </div>
      </section>

      {/* 5. Live Field Tagging Deployments Carousel */}
      <section id="deployments" className={s.deploySection}>
        <div className="wrap">
          <Reveal>
            <InteractiveCarousel
              subtitle="Proven Field Performance"
              title="Verified Field Deployments Across Nigeria"
              items={FIELD_ITEMS}
              isTagGallery={false}
            />
          </Reveal>
        </div>
      </section>

      {/* 6. Tag Materials & Client Gallery (Interactive Zoom Modal) */}
      <section id="tags" className={s.tagSection}>
        <div className="wrap">
          <Reveal>
            <div className={s.secHeader}>
              <span className={s.subBadge}>Industrial Substrates</span>
              <h2>Tags Built to Outlast Your Environment</h2>
              <p className={s.leadText}>
                We supply and affix custom-manufactured tags featuring your corporate branding, 1D/2D barcodes, and sequential serial numbers. Click any sample below to view full specifications.
              </p>
            </div>
          </Reveal>

          <InteractiveCarousel
            subtitle="Client Production Samples"
            title="Explore Our Label Substrates & Barcode Plates"
            items={TAG_ITEMS}
            isTagGallery={true}
          />
        </div>
      </section>

      {/* 7. 4-Step End-to-End Methodology */}
      <section id="process" className={s.processSection}>
        <div className="wrap">
          <Reveal>
            <div className={s.secHeaderCenter}>
              <span className={s.subBadge}>Seamless Execution</span>
              <h2>How We Work: The 4-Step Approach</h2>
              <p className={s.leadText}>
                Our systematic 4-phase audit cycle ensures minimal disruption to your daily operations while delivering comprehensive control.
              </p>
            </div>
          </Reveal>

          <div className={s.processSteps}>
            <div className={s.processStep}>
              <span className={s.stepPill}>Phase 01</span>
              <h3>Physical Verification</h3>
              <p>Our experienced field engineers visit all company branches, warehouses, and remote facilities to physically verify every item&apos;s condition, make, model, serial, and designated custodian.</p>
            </div>
            <div className={s.processStep}>
              <span className={s.stepPill}>Phase 02</span>
              <h3>Barcode & RFID Tagging</h3>
              <p>Every asset is cleaned, degreased, and permanently affixed with high-tack serialized barcode, QR, or RFID tags matching your required environmental durability tier.</p>
            </div>
            <div className={s.processStep}>
              <span className={s.stepPill}>Phase 03</span>
              <h3>Reconciliation & Clean-Up</h3>
              <p>We match physical inventory data line-by-line against your accounting fixed asset register. Discrepancies, stolen items, obsolescence, and ghost assets are isolated and resolved.</p>
            </div>
            <div className={s.processStep}>
              <span className={s.stepPill}>Phase 04</span>
              <h3>Software Governance</h3>
              <p>Your newly verified register is uploaded into our scalable asset management software for real-time tracking, barcode audits, depreciation tracking, and automated maintenance schedules.</p>
            </div>
          </div>
        </div>
      </section>

      {/* 8. Target Industries */}
      <section id="industries" className={s.industriesSection}>
        <div className="wrap">
          <Reveal>
            <div className={s.secHeaderCenter}>
              <span className={s.subBadge}>Who We Serve</span>
              <h2>Industries Where We Deliver Tangible Value</h2>
              <p className={s.leadText}>
                Wherever capital fixed assets drive operations and profitability, O.CUBE brings precision, audit assurance, and loss prevention.
              </p>
            </div>
          </Reveal>

          <div className={s.industriesGrid}>
            {INDUSTRIES_DATA.map((ind, i) => (
              <Reveal key={ind.title} delay={i * 50}>
                <div className={s.industryCard}>
                  <span className={s.indIcon}>{ind.icon}</span>
                  <h4>{ind.title}</h4>
                  <p>{ind.desc}</p>
                </div>
              </Reveal>
            ))}
          </div>
        </div>
      </section>

      {/* 9. Interactive Quote Calculator & Inquiry Form */}
      <QuoteCalculator />
    </>
  );
}
