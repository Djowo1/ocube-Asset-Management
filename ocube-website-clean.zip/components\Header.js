"use client";
import Link from "next/link";
import { useState, useEffect } from "react";
import Logo from "./Logo";
import styles from "./Header.module.css";

const NAV_LINKS = [
  { label: "Services", href: "/#services" },
  { label: "Interactive 3D", href: "/#interactive-cube" },
  { label: "Field Deployments", href: "/#deployments" },
  { label: "Tag Materials", href: "/#tags" },
  { label: "Process", href: "/#process" },
  { label: "Industries", href: "/#industries" },
  { label: "Get a Quote", href: "/#quote-calculator" },
];

export default function Header() {
  const [open, setOpen] = useState(false);
  const [scrolled, setScrolled] = useState(false);

  useEffect(() => {
    function onScroll() {
      setScrolled(window.scrollY > 40);
    }
    window.addEventListener("scroll", onScroll, { passive: true });
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  return (
    <header className={`${styles.header} ${scrolled ? styles.scrolled : ""}`}>
      {/* Top micro bar for fast contact & CAC badge */}
      <div className={styles.topBanner}>
        <div className={`wrap ${styles.topBannerInner}`}>
          <div className={styles.corpBadge}>
            <span className={styles.regPill}>RC 1247860</span>
            <span>Corporate Affairs Commission Registered · Since 2015</span>
          </div>
          <div className={styles.hotlines}>
            <span>📞 Direct Desk:</span>
            <a href="tel:+2348055260304">+234 805 526 0304</a>
            <span className={styles.sep}>|</span>
            <a href="tel:+2348081444046">+234 808 144 4046</a>
          </div>
        </div>
      </div>

      <div className={`wrap ${styles.navRow}`}>
        <Link href="/" aria-label="O. Cube Home" onClick={() => setOpen(false)} className={styles.logoLink}>
          <Logo size={36} />
        </Link>

        {/* Desktop Navigation */}
        <nav className={`${styles.nav} ${open ? styles.navOpen : ""}`}>
          {NAV_LINKS.map((link) => (
            <Link
              key={link.label}
              href={link.href}
              className={styles.navLink}
              onClick={() => setOpen(false)}
            >
              {link.label}
            </Link>
          ))}
          <Link
            href="/contact"
            className={`btn ${styles.ctaBtn}`}
            onClick={() => setOpen(false)}
          >
            Request Audit
          </Link>
        </nav>

        {/* Mobile Hamburger Button */}
        <button
          className={`${styles.burger} ${open ? styles.burgerOpen : ""}`}
          aria-expanded={open}
          aria-label="Toggle navigation menu"
          onClick={() => setOpen(!open)}
        >
          <span />
          <span />
          <span />
        </button>
      </div>
    </header>
  );
}
