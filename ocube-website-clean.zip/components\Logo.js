export default function Logo({ size = 34, text = true }) {
  return (
    <span style={{ display: "inline-flex", alignItems: "center", gap: 10, color: "#fff", lineHeight: 1.05 }}>
      <svg width={size} height={size} viewBox="0 0 40 40" aria-hidden="true">
        <path d="M20 2 36 11 20 20 4 11Z" fill="#ffc21a" />
        <path d="M4 11 20 20V38L4 29Z" fill="#2447c7" />
        <path d="M36 11 20 20V38L36 29Z" fill="#8096f0" />
      </svg>
      {text && (<span><b style={{ fontSize: "1.15rem", letterSpacing: ".04em" }}>O.CUBE</b><br /><small style={{ fontSize: ".6rem", letterSpacing: ".14em", opacity: .75 }}>ASSET MANAGEMENT LIMITED</small></span>)}
    </span>
  );
}
