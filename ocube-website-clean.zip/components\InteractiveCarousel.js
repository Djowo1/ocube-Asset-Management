"use client";
import { useState, useRef } from "react";
import Image from "next/image";
import styles from "./InteractiveCarousel.module.css";

export default function InteractiveCarousel({ title, subtitle, items = [], isTagGallery = false }) {
  const [selectedTag, setSelectedTag] = useState(null);
  const scrollRef = useRef(null);

  function scroll(direction) {
    if (!scrollRef.current) return;
    const amount = direction === "left" ? -340 : 340;
    scrollRef.current.scrollBy({ left: amount, behavior: "smooth" });
  }

  return (
    <div className={styles.carouselContainer}>
      <div className={styles.headerRow}>
        <div>
          {subtitle && <span className={styles.subtitle}>{subtitle}</span>}
          {title && <h2 className={styles.title}>{title}</h2>}
        </div>
        <div className={styles.controls}>
          <button
            onClick={() => scroll("left")}
            className={styles.controlBtn}
            aria-label="Scroll left"
          >
            ←
          </button>
          <button
            onClick={() => scroll("right")}
            className={styles.controlBtn}
            aria-label="Scroll right"
          >
            →
          </button>
        </div>
      </div>

      <div className={styles.track} ref={scrollRef}>
        {items.map((item, idx) => (
          <div
            key={idx}
            className={`${styles.card} ${isTagGallery ? styles.tagCard : ""}`}
            onClick={() => isTagGallery && setSelectedTag(item)}
          >
            <div className={styles.imageBox}>
              <Image
                src={item.src}
                alt={item.title || item.alt || "O.Cube asset showcase"}
                width={400}
                height={280}
                className={styles.image}
              />
              {item.material && (
                <span className={styles.materialTag}>{item.material}</span>
              )}
              {item.category && (
                <span className={styles.categoryTag}>{item.category}</span>
              )}
            </div>

            <div className={styles.cardContent}>
              <h3 className={styles.cardTitle}>{item.title}</h3>
              {item.code && (
                <p className={styles.cardCode}>
                  <span>ID / Serial:</span> <code>{item.code}</code>
                </p>
              )}
              {item.desc && <p className={styles.cardDesc}>{item.desc}</p>}
              {isTagGallery && (
                <span className={styles.zoomHint}>Click to Inspect Label</span>
              )}
            </div>
          </div>
        ))}
      </div>

      {/* Label Inspection Modal */}
      {selectedTag && (
        <div className={styles.modalBackdrop} onClick={() => setSelectedTag(null)}>
          <div className={styles.modalContent} onClick={(e) => e.stopPropagation()}>
            <button
              className={styles.closeBtn}
              onClick={() => setSelectedTag(null)}
              aria-label="Close"
            >
              ×
            </button>
            <div className={styles.modalImageWrapper}>
              <Image
                src={selectedTag.src}
                alt={selectedTag.title}
                width={650}
                height={480}
                className={styles.modalImage}
              />
            </div>
            <div className={styles.modalInfo}>
              <h3>{selectedTag.title}</h3>
              <p><strong>Specification / Substrate:</strong> {selectedTag.material}</p>
              {selectedTag.code && (
                <p><strong>Sample Identifier:</strong> <code>{selectedTag.code}</code></p>
              )}
              <p className={styles.modalNote}>
                O.CUBE customizes tag materials, barcode symbologies (Code 128, QR, Datamatrix), adhesives, and durability ratings for indoor, outdoor, chemical, and heavy-duty industrial exposure.
              </p>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

